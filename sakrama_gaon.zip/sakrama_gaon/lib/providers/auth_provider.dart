import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/fcm_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final FcmService _fcmService = FcmService();

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _error;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _currentUser != null;

  AuthProvider() {
    _authService.authStateChanges.listen((user) async {
      if (user == null) {
        _currentUser = null;
        notifyListeners();
      } else {
        final profile = await _authService.fetchUserProfile(user.uid);
        _currentUser = profile;
        notifyListeners();
        if (profile != null) {
          await _fcmService.initialize(profile.uid);
        }
      }
    });
  }

  Future<bool> signInWithGoogle() async {
    _setLoading(true);
    try {
      final user = await _authService.signInWithGoogle();
      if (user == null) {
        _setLoading(false);
        return false;
      }
      if (user.isBanned) {
        _error = 'This account has been banned by an administrator.';
        await _authService.signOut();
        _setLoading(false);
        return false;
      }
      _currentUser = user;
      _setLoading(false);
      return true;
    } catch (e) {
      _error = e.toString();
      _setLoading(false);
      return false;
    }
  }

  Future<void> sendOtp({
    required String phoneNumber,
    required void Function(String verificationId) codeSent,
  }) async {
    _setLoading(true);
    await _authService.sendOtp(
      phoneNumber: phoneNumber,
      codeSent: (id) {
        _setLoading(false);
        codeSent(id);
      },
      onError: (err) {
        _error = err;
        _setLoading(false);
        notifyListeners();
      },
      onAutoVerified: (user) {
        _currentUser = user;
        _setLoading(false);
        notifyListeners();
      },
    );
  }

  Future<bool> verifyOtp({
    required String verificationId,
    required String smsCode,
    required String displayName,
  }) async {
    _setLoading(true);
    try {
      final user = await _authService.verifyOtp(
        verificationId: verificationId,
        smsCode: smsCode,
        displayName: displayName,
      );
      _currentUser = user;
      _setLoading(false);
      return user != null;
    } catch (e) {
      _error = e.toString();
      _setLoading(false);
      return false;
    }
  }

  Future<void> signOut() async {
    await _authService.signOut();
    _currentUser = null;
    notifyListeners();
  }

  void refreshUser() async {
    if (_currentUser == null) return;
    final profile = await _authService.fetchUserProfile(_currentUser!.uid);
    _currentUser = profile;
    notifyListeners();
  }

  void _setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }
}
