import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/post_model.dart';
import '../services/firestore_service.dart';

class PostProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();

  final List<PostModel> _posts = [];
  DocumentSnapshot? _lastDoc;
  bool _isLoading = false;
  bool _hasMore = true;

  List<PostModel> get posts => _posts;
  bool get isLoading => _isLoading;
  bool get hasMore => _hasMore;

  Future<void> loadInitial() async {
    _posts.clear();
    _lastDoc = null;
    _hasMore = true;
    await loadMore();
  }

  Future<void> loadMore() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;
    notifyListeners();

    final snap = await _firestoreService.fetchFeedRaw(lastDoc: _lastDoc, limit: 10);
    if (snap.docs.isEmpty) {
      _hasMore = false;
    } else {
      _lastDoc = snap.docs.last;
      _posts.addAll(snap.docs
          .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id)));
      if (snap.docs.length < 10) _hasMore = false;
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> refresh() => loadInitial();

  Future<void> toggleLike(String postId, String uid) async {
    final index = _posts.indexWhere((p) => p.id == postId);
    if (index == -1) return;
    final post = _posts[index];
    final isLiked = post.likes.contains(uid);
    final updatedLikes = List<String>.from(post.likes);
    if (isLiked) {
      updatedLikes.remove(uid);
    } else {
      updatedLikes.add(uid);
    }
    _posts[index] = PostModel(
      id: post.id,
      authorId: post.authorId,
      authorName: post.authorName,
      authorPhoto: post.authorPhoto,
      village: post.village,
      text: post.text,
      imageUrls: post.imageUrls,
      videoUrl: post.videoUrl,
      type: post.type,
      likes: updatedLikes,
      commentCount: post.commentCount,
      isApproved: post.isApproved,
      isReported: post.isReported,
      createdAt: post.createdAt,
    );
    notifyListeners();
    await _firestoreService.toggleLike(postId, uid, isLiked);
  }

  Future<void> createPost(PostModel post) async {
    await _firestoreService.createPost(post);
    await refresh();
  }
}
