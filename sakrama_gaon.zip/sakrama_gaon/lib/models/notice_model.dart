import 'package:cloud_firestore/cloud_firestore.dart';

enum NoticeCategory { government, panchayat, school, temple, festival, emergency }

extension NoticeCategoryX on NoticeCategory {
  String get label {
    switch (this) {
      case NoticeCategory.government:
        return 'Government';
      case NoticeCategory.panchayat:
        return 'Panchayat';
      case NoticeCategory.school:
        return 'School';
      case NoticeCategory.temple:
        return 'Temple';
      case NoticeCategory.festival:
        return 'Festival';
      case NoticeCategory.emergency:
        return 'Emergency';
    }
  }
}

class NoticeModel {
  final String id;
  final String title;
  final String description;
  final NoticeCategory category;
  final String postedBy;
  final String? imageUrl;
  final bool isEmergency;
  final DateTime createdAt;

  NoticeModel({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.postedBy,
    this.imageUrl,
    this.isEmergency = false,
    required this.createdAt,
  });

  factory NoticeModel.fromMap(Map<String, dynamic> map, String id) {
    return NoticeModel(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      category: NoticeCategory.values.firstWhere(
          (e) => e.name == (map['category'] ?? 'government'),
          orElse: () => NoticeCategory.government),
      postedBy: map['postedBy'] ?? 'Admin',
      imageUrl: map['imageUrl'],
      isEmergency: map['isEmergency'] ?? false,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'category': category.name,
      'postedBy': postedBy,
      'imageUrl': imageUrl,
      'isEmergency': isEmergency,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}
