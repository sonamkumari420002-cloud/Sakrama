import 'package:cloud_firestore/cloud_firestore.dart';

enum NotificationType { like, comment, announcement, event, follow }

class NotificationModel {
  final String id;
  final String userId;
  final NotificationType type;
  final String title;
  final String body;
  final String? relatedId;
  final String? actorPhoto;
  final bool isRead;
  final DateTime createdAt;

  NotificationModel({
    required this.id,
    required this.userId,
    required this.type,
    required this.title,
    required this.body,
    this.relatedId,
    this.actorPhoto,
    this.isRead = false,
    required this.createdAt,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> map, String id) {
    return NotificationModel(
      id: id,
      userId: map['userId'] ?? '',
      type: NotificationType.values.firstWhere(
          (e) => e.name == (map['type'] ?? 'announcement'),
          orElse: () => NotificationType.announcement),
      title: map['title'] ?? '',
      body: map['body'] ?? '',
      relatedId: map['relatedId'],
      actorPhoto: map['actorPhoto'],
      isRead: map['isRead'] ?? false,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'type': type.name,
      'title': title,
      'body': body,
      'relatedId': relatedId,
      'actorPhoto': actorPhoto,
      'isRead': isRead,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}
