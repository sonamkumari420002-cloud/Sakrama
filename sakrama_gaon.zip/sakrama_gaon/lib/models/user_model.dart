import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String name;
  final String? email;
  final String? phone;
  final String photoUrl;
  final String village;
  final String bio;
  final bool isAdmin;
  final bool isBanned;
  final List<String> followers;
  final List<String> following;
  final DateTime createdAt;

  UserModel({
    required this.uid,
    required this.name,
    this.email,
    this.phone,
    this.photoUrl = '',
    this.village = '',
    this.bio = '',
    this.isAdmin = false,
    this.isBanned = false,
    this.followers = const [],
    this.following = const [],
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String uid) {
    return UserModel(
      uid: uid,
      name: map['name'] ?? 'Villager',
      email: map['email'],
      phone: map['phone'],
      photoUrl: map['photoUrl'] ?? '',
      village: map['village'] ?? '',
      bio: map['bio'] ?? '',
      isAdmin: map['isAdmin'] ?? false,
      isBanned: map['isBanned'] ?? false,
      followers: List<String>.from(map['followers'] ?? []),
      following: List<String>.from(map['following'] ?? []),
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'photoUrl': photoUrl,
      'village': village,
      'bio': bio,
      'isAdmin': isAdmin,
      'isBanned': isBanned,
      'followers': followers,
      'following': following,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  UserModel copyWith({
    String? name,
    String? photoUrl,
    String? village,
    String? bio,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email,
      phone: phone,
      photoUrl: photoUrl ?? this.photoUrl,
      village: village ?? this.village,
      bio: bio ?? this.bio,
      isAdmin: isAdmin,
      isBanned: isBanned,
      followers: followers,
      following: following,
      createdAt: createdAt,
    );
  }
}
