import 'package:cloud_firestore/cloud_firestore.dart';

enum PostType { text, image, video }

class PostModel {
  final String id;
  final String authorId;
  final String authorName;
  final String authorPhoto;
  final String village;
  final String text;
  final List<String> imageUrls;
  final String? videoUrl;
  final PostType type;
  final List<String> likes;
  final int commentCount;
  final bool isApproved;
  final bool isReported;
  final DateTime createdAt;

  PostModel({
    required this.id,
    required this.authorId,
    required this.authorName,
    required this.authorPhoto,
    this.village = '',
    required this.text,
    this.imageUrls = const [],
    this.videoUrl,
    this.type = PostType.text,
    this.likes = const [],
    this.commentCount = 0,
    this.isApproved = true,
    this.isReported = false,
    required this.createdAt,
  });

  factory PostModel.fromMap(Map<String, dynamic> map, String id) {
    return PostModel(
      id: id,
      authorId: map['authorId'] ?? '',
      authorName: map['authorName'] ?? 'Villager',
      authorPhoto: map['authorPhoto'] ?? '',
      village: map['village'] ?? '',
      text: map['text'] ?? '',
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      videoUrl: map['videoUrl'],
      type: PostType.values.firstWhere(
          (e) => e.name == (map['type'] ?? 'text'),
          orElse: () => PostType.text),
      likes: List<String>.from(map['likes'] ?? []),
      commentCount: map['commentCount'] ?? 0,
      isApproved: map['isApproved'] ?? true,
      isReported: map['isReported'] ?? false,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'authorId': authorId,
      'authorName': authorName,
      'authorPhoto': authorPhoto,
      'village': village,
      'text': text,
      'imageUrls': imageUrls,
      'videoUrl': videoUrl,
      'type': type.name,
      'likes': likes,
      'commentCount': commentCount,
      'isApproved': isApproved,
      'isReported': isReported,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}

class CommentModel {
  final String id;
  final String authorId;
  final String authorName;
  final String authorPhoto;
  final String text;
  final String? parentId;
  final DateTime createdAt;

  CommentModel({
    required this.id,
    required this.authorId,
    required this.authorName,
    required this.authorPhoto,
    required this.text,
    this.parentId,
    required this.createdAt,
  });

  factory CommentModel.fromMap(Map<String, dynamic> map, String id) {
    return CommentModel(
      id: id,
      authorId: map['authorId'] ?? '',
      authorName: map['authorName'] ?? 'Villager',
      authorPhoto: map['authorPhoto'] ?? '',
      text: map['text'] ?? '',
      parentId: map['parentId'],
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'authorId': authorId,
      'authorName': authorName,
      'authorPhoto': authorPhoto,
      'text': text,
      'parentId': parentId,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}
