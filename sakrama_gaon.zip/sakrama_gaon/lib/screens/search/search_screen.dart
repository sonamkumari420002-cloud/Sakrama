import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../models/post_model.dart';
import '../../models/event_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import '../events/event_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with SingleTickerProviderStateMixin {
  final _controller = TextEditingController();
  final _firestoreService = FirestoreService();
  late final TabController _tabController;

  List<UserModel> _users = [];
  List<PostModel> _posts = [];
  List<EventModel> _events = [];
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _users = [];
        _posts = [];
        _events = [];
      });
      return;
    }
    setState(() => _isSearching = true);
    final users = await _firestoreService.searchUsers(query);
    final posts = await _firestoreService.searchPosts(query);
    final events = await _firestoreService.searchEvents(query);
    setState(() {
      _users = users;
      _posts = posts;
      _events = events;
      _isSearching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Search users, posts, events...',
            hintStyle: TextStyle(color: Colors.white70),
            border: InputBorder.none,
          ),
          onSubmitted: _search,
          onChanged: (v) {
            if (v.length > 2) _search(v);
          },
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: [
            Tab(text: 'Users (${_users.length})'),
            Tab(text: 'Posts (${_posts.length})'),
            Tab(text: 'Events (${_events.length})'),
          ],
        ),
      ),
      body: _isSearching
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _users.isEmpty
                    ? const Center(child: Text('Search for villagers by name'))
                    : ListView.builder(
                        itemCount: _users.length,
                        itemBuilder: (context, index) {
                          final u = _users[index];
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: AppColors.paleGreen,
                              backgroundImage: u.photoUrl.isNotEmpty ? NetworkImage(u.photoUrl) : null,
                              child: u.photoUrl.isEmpty ? Text(u.name[0]) : null,
                            ),
                            title: Text(u.name),
                            subtitle: Text(u.village),
                          );
                        },
                      ),
                _posts.isEmpty
                    ? const Center(child: Text('Search posts by keyword'))
                    : ListView.builder(
                        itemCount: _posts.length,
                        itemBuilder: (context, index) => ListTile(
                          title: Text(_posts[index].authorName),
                          subtitle: Text(_posts[index].text, maxLines: 2, overflow: TextOverflow.ellipsis),
                        ),
                      ),
                _events.isEmpty
                    ? const Center(child: Text('Search upcoming events'))
                    : ListView.builder(
                        itemCount: _events.length,
                        itemBuilder: (context, index) => ListTile(
                          leading: const Icon(Icons.event, color: AppColors.primaryGreen),
                          title: Text(_events[index].title),
                          subtitle: Text(_events[index].location),
                          onTap: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => EventDetailScreen(event: _events[index]))),
                        ),
                      ),
              ],
            ),
    );
  }
}
