import 'package:flutter/material.dart';
import '../../models/post_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import 'upload_notice_screen.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> with SingleTickerProviderStateMixin {
  final _firestoreService = FirestoreService();
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: 'Reported Posts'),
            Tab(text: 'Manage Users'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const UploadNoticeScreen())),
        icon: const Icon(Icons.campaign),
        label: const Text('New Announcement'),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _ReportedPostsTab(firestoreService: _firestoreService),
          _ManageUsersTab(firestoreService: _firestoreService),
        ],
      ),
    );
  }
}

class _ReportedPostsTab extends StatefulWidget {
  final FirestoreService firestoreService;
  const _ReportedPostsTab({required this.firestoreService});

  @override
  State<_ReportedPostsTab> createState() => _ReportedPostsTabState();
}

class _ReportedPostsTabState extends State<_ReportedPostsTab> {
  List<PostModel> _posts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final posts = await widget.firestoreService.fetchReportedPosts();
    setState(() {
      _posts = posts;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_posts.isEmpty) return const Center(child: Text('No reported posts 🎉'));

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: _posts.length,
        itemBuilder: (context, index) {
          final post = _posts[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post.authorName, style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(post.text),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          await widget.firestoreService.approvePost(post.id);
                          _load();
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryGreen),
                        child: const Text('Approve'),
                      ),
                      const SizedBox(width: 10),
                      OutlinedButton(
                        onPressed: () async {
                          await widget.firestoreService.deletePost(post.id);
                          _load();
                        },
                        style: OutlinedButton.styleFrom(foregroundColor: AppColors.error),
                        child: const Text('Delete'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ManageUsersTab extends StatefulWidget {
  final FirestoreService firestoreService;
  const _ManageUsersTab({required this.firestoreService});

  @override
  State<_ManageUsersTab> createState() => _ManageUsersTabState();
}

class _ManageUsersTabState extends State<_ManageUsersTab> {
  List<UserModel> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final users = await widget.firestoreService.fetchAllUsers();
    setState(() {
      _users = users;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: _users.length,
        itemBuilder: (context, index) {
          final u = _users[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: AppColors.paleGreen,
              backgroundImage: u.photoUrl.isNotEmpty ? NetworkImage(u.photoUrl) : null,
              child: u.photoUrl.isEmpty ? Text(u.name[0]) : null,
            ),
            title: Text(u.name),
            subtitle: Text(u.isBanned ? 'Banned' : u.village),
            trailing: Switch(
              value: !u.isBanned,
              activeColor: AppColors.primaryGreen,
              onChanged: (val) async {
                await widget.firestoreService.banUser(u.uid, !val);
                _load();
              },
            ),
          );
        },
      ),
    );
  }
}
