import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/notice_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';

class UploadNoticeScreen extends StatefulWidget {
  const UploadNoticeScreen({super.key});

  @override
  State<UploadNoticeScreen> createState() => _UploadNoticeScreenState();
}

class _UploadNoticeScreenState extends State<UploadNoticeScreen> {
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  NoticeCategory _category = NoticeCategory.government;
  bool _isEmergency = false;
  bool _isSubmitting = false;
  final _firestoreService = FirestoreService();

  Future<void> _submit() async {
    final user = context.read<AuthProvider>().currentUser;
    if (user == null || _titleController.text.trim().isEmpty) return;

    setState(() => _isSubmitting = true);
    final notice = NoticeModel(
      id: '',
      title: _titleController.text.trim(),
      description: _descController.text.trim(),
      category: _category,
      postedBy: user.name,
      isEmergency: _isEmergency,
      createdAt: DateTime.now(),
    );
    await _firestoreService.createNotice(notice);
    setState(() => _isSubmitting = false);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload Notice')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descController,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<NoticeCategory>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Category'),
              items: NoticeCategory.values
                  .map((c) => DropdownMenuItem(value: c, child: Text(c.label)))
                  .toList(),
              onChanged: (val) => setState(() => _category = val!),
            ),
            SwitchListTile(
              title: const Text('Mark as Emergency'),
              value: _isEmergency,
              onChanged: (val) => setState(() => _isEmergency = val),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isSubmitting ? null : _submit,
              child: Text(_isSubmitting ? 'Publishing...' : 'Publish Notice'),
            ),
          ],
        ),
      ),
    );
  }
}
