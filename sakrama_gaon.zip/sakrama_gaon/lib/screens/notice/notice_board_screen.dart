import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../models/notice_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/main_nav_scaffold.dart';
import '../admin/upload_notice_screen.dart';

class NoticeBoardScreen extends StatefulWidget {
  const NoticeBoardScreen({super.key});

  @override
  State<NoticeBoardScreen> createState() => _NoticeBoardScreenState();
}

class _NoticeBoardScreenState extends State<NoticeBoardScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  NoticeCategory? _selectedCategory;

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Notice Board')),
      floatingActionButton: (user?.isAdmin ?? false)
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const UploadNoticeScreen())),
              icon: const Icon(Icons.add),
              label: const Text('New Notice'),
            )
          : null,
      body: Column(
        children: [
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                CategoryChip(
                  label: 'All',
                  selected: _selectedCategory == null,
                  onTap: () => setState(() => _selectedCategory = null),
                ),
                ...NoticeCategory.values.map((c) => CategoryChip(
                      label: c.label,
                      selected: _selectedCategory == c,
                      onTap: () => setState(() => _selectedCategory = c),
                    )),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<NoticeModel>>(
              stream: _firestoreService.streamNotices(category: _selectedCategory),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final notices = snapshot.data!;
                if (notices.isEmpty) {
                  return const Center(child: Text('No notices in this category yet'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: notices.length,
                  itemBuilder: (context, index) {
                    final notice = notices[index];
                    return Card(
                      color: notice.isEmergency ? Colors.red.shade50 : null,
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: notice.isEmergency
                              ? AppColors.error.withOpacity(0.15)
                              : AppColors.paleGreen,
                          child: Icon(
                            _iconFor(notice.category),
                            color: notice.isEmergency ? AppColors.error : AppColors.primaryGreen,
                          ),
                        ),
                        title: Text(notice.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text(notice.description, maxLines: 3, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Text(
                              '${notice.category.label} • ${timeago.format(notice.createdAt)}',
                              style: TextStyle(fontSize: 11, color: AppColors.textGrey),
                            ),
                          ],
                        ),
                        isThreeLine: true,
                        onTap: () => _showNoticeDetail(context, notice),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  IconData _iconFor(NoticeCategory category) {
    switch (category) {
      case NoticeCategory.government:
        return Icons.account_balance;
      case NoticeCategory.panchayat:
        return Icons.groups;
      case NoticeCategory.school:
        return Icons.school;
      case NoticeCategory.temple:
        return Icons.temple_hindu;
      case NoticeCategory.festival:
        return Icons.celebration;
      case NoticeCategory.emergency:
        return Icons.warning_amber;
    }
  }

  void _showNoticeDetail(BuildContext context, NoticeModel notice) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(notice.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('${notice.category.label} • Posted by ${notice.postedBy}',
                style: TextStyle(color: AppColors.textGrey, fontSize: 12)),
            const SizedBox(height: 16),
            Text(notice.description),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
