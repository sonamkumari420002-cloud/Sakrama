import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:uuid/uuid.dart';
import '../../models/post_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';

class CommentsScreen extends StatefulWidget {
  final String postId;
  const CommentsScreen({super.key, required this.postId});

  @override
  State<CommentsScreen> createState() => _CommentsScreenState();
}

class _CommentsScreenState extends State<CommentsScreen> {
  final _controller = TextEditingController();
  final _firestoreService = FirestoreService();
  String? _replyToId;
  String? _replyToName;

  Future<void> _postComment() async {
    final text = _controller.text.trim();
    final user = context.read<AuthProvider>().currentUser;
    if (text.isEmpty || user == null) return;

    final comment = CommentModel(
      id: const Uuid().v4(),
      authorId: user.uid,
      authorName: user.name,
      authorPhoto: user.photoUrl,
      text: text,
      parentId: _replyToId,
      createdAt: DateTime.now(),
    );
    await _firestoreService.addComment(widget.postId, comment);
    _controller.clear();
    setState(() {
      _replyToId = null;
      _replyToName = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comments')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<CommentModel>>(
              stream: _firestoreService.streamComments(widget.postId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final comments = snapshot.data!;
                if (comments.isEmpty) {
                  return const Center(child: Text('No comments yet. Start the discussion!'));
                }
                final topLevel = comments.where((c) => c.parentId == null).toList();

                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: topLevel.length,
                  itemBuilder: (context, index) {
                    final comment = topLevel[index];
                    final replies = comments.where((c) => c.parentId == comment.id).toList();
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _CommentTile(
                          comment: comment,
                          onReply: () => setState(() {
                            _replyToId = comment.id;
                            _replyToName = comment.authorName;
                          }),
                        ),
                        ...replies.map((r) => Padding(
                              padding: const EdgeInsets.only(left: 40),
                              child: _CommentTile(
                                comment: r,
                                onReply: () => setState(() {
                                  _replyToId = comment.id;
                                  _replyToName = comment.authorName;
                                }),
                              ),
                            )),
                        const SizedBox(height: 8),
                      ],
                    );
                  },
                );
              },
            ),
          ),
          if (_replyToName != null)
            Container(
              width: double.infinity,
              color: AppColors.paleGreen,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  Expanded(child: Text('Replying to $_replyToName')),
                  IconButton(
                    icon: const Icon(Icons.close, size: 18),
                    onPressed: () => setState(() {
                      _replyToId = null;
                      _replyToName = null;
                    }),
                  ),
                ],
              ),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(hintText: 'Write a comment...'),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: AppColors.primaryGreen),
                    onPressed: _postComment,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CommentTile extends StatelessWidget {
  final CommentModel comment;
  final VoidCallback onReply;
  const _CommentTile({required this.comment, required this.onReply});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: AppColors.paleGreen,
            backgroundImage:
                comment.authorPhoto.isNotEmpty ? NetworkImage(comment.authorPhoto) : null,
            child: comment.authorPhoto.isEmpty
                ? Text(comment.authorName.isNotEmpty ? comment.authorName[0] : 'V')
                : null,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(comment.authorName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text(comment.text, style: const TextStyle(fontSize: 14)),
                Row(
                  children: [
                    Text(timeago.format(comment.createdAt),
                        style: TextStyle(fontSize: 11, color: AppColors.textGrey)),
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: onReply,
                      child: Text('Reply',
                          style: TextStyle(fontSize: 11, color: AppColors.primaryGreen, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
