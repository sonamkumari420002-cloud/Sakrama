import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../models/post_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/post_provider.dart';
import '../../services/storage_service.dart';
import '../../utils/app_theme.dart';

class CreatePostScreen extends StatefulWidget {
  const CreatePostScreen({super.key});

  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  final _textController = TextEditingController();
  final _picker = ImagePicker();
  final _storageService = StorageService();

  final List<File> _images = [];
  File? _video;
  bool _isUploading = false;
  double _progress = 0;

  Future<void> _pickImages() async {
    final picked = await _picker.pickMultiImage(imageQuality: 80);
    if (picked.isNotEmpty) {
      setState(() {
        _images.addAll(picked.map((x) => File(x.path)));
        _video = null;
      });
    }
  }

  Future<void> _pickVideo() async {
    final picked = await _picker.pickVideo(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _video = File(picked.path);
        _images.clear();
      });
    }
  }

  Future<void> _submitPost() async {
    final text = _textController.text.trim();
    final authProvider = context.read<AuthProvider>();
    final user = authProvider.currentUser;
    if (user == null) return;

    if (text.isEmpty && _images.isEmpty && _video == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Write something or add media')));
      return;
    }

    setState(() {
      _isUploading = true;
      _progress = 0;
    });

    try {
      List<String> imageUrls = [];
      String? videoUrl;
      PostType type = PostType.text;

      if (_images.isNotEmpty) {
        imageUrls = await _storageService.uploadMultipleImages(
          files: _images,
          folder: 'posts/images',
          onProgress: (p) => setState(() => _progress = p),
        );
        type = PostType.image;
      } else if (_video != null) {
        videoUrl = await _storageService.uploadFile(
          file: _video!,
          folder: 'posts/videos',
          onProgress: (p) => setState(() => _progress = p),
        );
        type = PostType.video;
      }

      final post = PostModel(
        id: '',
        authorId: user.uid,
        authorName: user.name,
        authorPhoto: user.photoUrl,
        village: user.village,
        text: text,
        imageUrls: imageUrls,
        videoUrl: videoUrl,
        type: type,
        createdAt: DateTime.now(),
      );

      await context.read<PostProvider>().createPost(post);

      _textController.clear();
      setState(() {
        _images.clear();
        _video = null;
        _isUploading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Post shared with the village!')));
      }
    } catch (e) {
      setState(() => _isUploading = false);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Upload failed: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Create Post')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppColors.paleGreen,
                  backgroundImage:
                      (user?.photoUrl.isNotEmpty ?? false) ? NetworkImage(user!.photoUrl) : null,
                  child: (user?.photoUrl.isEmpty ?? true)
                      ? Text(user?.name.substring(0, 1) ?? 'V')
                      : null,
                ),
                const SizedBox(width: 10),
                Text(user?.name ?? 'Villager',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _textController,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: "What's happening in the village today?",
              ),
            ),
            const SizedBox(height: 12),
            if (_images.isNotEmpty)
              SizedBox(
                height: 90,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _images.length,
                  itemBuilder: (context, index) => Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(_images[index],
                              width: 90, height: 90, fit: BoxFit.cover),
                        ),
                        Positioned(
                          top: 2,
                          right: 2,
                          child: GestureDetector(
                            onTap: () => setState(() => _images.removeAt(index)),
                            child: const CircleAvatar(
                              radius: 10,
                              backgroundColor: Colors.black54,
                              child: Icon(Icons.close, size: 14, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            if (_video != null)
              Container(
                height: 90,
                width: 90,
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.videocam, color: Colors.white, size: 32),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: _isUploading ? null : _pickImages,
                  icon: const Icon(Icons.image_outlined),
                  label: const Text('Photos'),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  onPressed: _isUploading ? null : _pickVideo,
                  icon: const Icon(Icons.videocam_outlined),
                  label: const Text('Video'),
                ),
              ],
            ),
            const Spacer(),
            if (_isUploading) ...[
              LinearProgressIndicator(value: _progress),
              const SizedBox(height: 8),
              Text('Uploading ${(_progress * 100).toStringAsFixed(0)}%'),
              const SizedBox(height: 12),
            ],
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isUploading ? null : _submitPost,
                child: Text(_isUploading ? 'Posting...' : 'Post to Village'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
