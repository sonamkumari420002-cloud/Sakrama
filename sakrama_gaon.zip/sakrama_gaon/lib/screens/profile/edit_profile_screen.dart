import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../utils/app_theme.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late final TextEditingController _nameController;
  late final TextEditingController _villageController;
  late final TextEditingController _bioController;
  File? _pickedPhoto;
  bool _isSaving = false;

  final _firestoreService = FirestoreService();
  final _storageService = StorageService();

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthProvider>().currentUser!;
    _nameController = TextEditingController(text: user.name);
    _villageController = TextEditingController(text: user.village);
    _bioController = TextEditingController(text: user.bio);
  }

  Future<void> _pickPhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked != null) {
      setState(() => _pickedPhoto = File(picked.path));
    }
  }

  Future<void> _save() async {
    final authProvider = context.read<AuthProvider>();
    final user = authProvider.currentUser!;
    setState(() => _isSaving = true);

    String photoUrl = user.photoUrl;
    if (_pickedPhoto != null) {
      photoUrl = await _storageService.uploadFile(
        file: _pickedPhoto!,
        folder: 'profile_photos',
      );
    }

    await _firestoreService.updateProfile(user.uid, {
      'name': _nameController.text.trim(),
      'village': _villageController.text.trim(),
      'bio': _bioController.text.trim(),
      'photoUrl': photoUrl,
    });

    authProvider.refreshUser();
    setState(() => _isSaving = false);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser!;

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            Center(
              child: GestureDetector(
                onTap: _pickPhoto,
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: AppColors.paleGreen,
                      backgroundImage: _pickedPhoto != null
                          ? FileImage(_pickedPhoto!)
                          : (user.photoUrl.isNotEmpty ? NetworkImage(user.photoUrl) : null) as ImageProvider?,
                    ),
                    const Positioned(
                      bottom: 0,
                      right: 0,
                      child: CircleAvatar(
                        radius: 16,
                        backgroundColor: AppColors.primaryGreen,
                        child: Icon(Icons.camera_alt, size: 16, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 12),
            TextField(controller: _villageController, decoration: const InputDecoration(labelText: 'Village')),
            const SizedBox(height: 12),
            TextField(
              controller: _bioController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Bio'),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              child: Text(_isSaving ? 'Saving...' : 'Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}
