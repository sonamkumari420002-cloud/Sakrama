import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/post_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/post_card.dart';
import '../auth/login_screen.dart';
import '../admin/admin_panel_screen.dart';
import '../events/events_screen.dart';
import '../gallery/gallery_screen.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  final FirestoreService _firestoreService = FirestoreService();
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;
    final themeProvider = context.watch<ThemeProvider>();

    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(themeProvider.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => context.read<ThemeProvider>().toggleTheme(),
          ),
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'logout') {
                await context.read<AuthProvider>().signOut();
                if (context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false,
                  );
                }
              } else if (value == 'admin') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanelScreen()));
              }
            },
            itemBuilder: (context) => [
              if (user.isAdmin)
                const PopupMenuItem(value: 'admin', child: Text('Admin Panel')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 44,
                  backgroundColor: AppColors.paleGreen,
                  backgroundImage: user.photoUrl.isNotEmpty ? NetworkImage(user.photoUrl) : null,
                  child: user.photoUrl.isEmpty
                      ? Text(user.name.isNotEmpty ? user.name[0].toUpperCase() : 'V',
                          style: const TextStyle(fontSize: 32))
                      : null,
                ),
                const SizedBox(height: 12),
                Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                if (user.village.isNotEmpty)
                  Text(user.village, style: TextStyle(color: AppColors.textGrey)),
                if (user.bio.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(user.bio, textAlign: TextAlign.center),
                ],
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _statColumn('${user.followers.length}', 'Followers'),
                    const SizedBox(width: 32),
                    _statColumn('${user.following.length}', 'Following'),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                            context, MaterialPageRoute(builder: (_) => const EditProfileScreen())),
                        icon: const Icon(Icons.edit_outlined),
                        label: const Text('Edit Profile'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                            context, MaterialPageRoute(builder: (_) => const EventsScreen())),
                        icon: const Icon(Icons.event_outlined),
                        label: const Text('Events'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => const GalleryScreen())),
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Village Gallery'),
                  ),
                ),
              ],
            ),
          ),
          TabBar(
            controller: _tabController,
            labelColor: AppColors.primaryGreen,
            tabs: const [
              Tab(text: 'My Posts'),
              Tab(text: 'Saved'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _MyPostsTab(uid: user.uid, firestoreService: _firestoreService),
                _SavedPostsTab(uid: user.uid, firestoreService: _firestoreService),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statColumn(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        Text(label, style: TextStyle(color: AppColors.textGrey, fontSize: 12)),
      ],
    );
  }
}

class _MyPostsTab extends StatelessWidget {
  final String uid;
  final FirestoreService firestoreService;
  const _MyPostsTab({required this.uid, required this.firestoreService});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<PostModel>>(
      future: firestoreService.fetchUserPosts(uid),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final posts = snapshot.data!;
        if (posts.isEmpty) return const Center(child: Text('No posts yet'));
        return ListView.builder(
          itemCount: posts.length,
          itemBuilder: (context, index) => PostCard(
            post: posts[index],
            currentUid: uid,
            onLike: () {},
            onReport: () {},
            onSave: () {},
          ),
        );
      },
    );
  }
}

class _SavedPostsTab extends StatelessWidget {
  final String uid;
  final FirestoreService firestoreService;
  const _SavedPostsTab({required this.uid, required this.firestoreService});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<PostModel>>(
      future: firestoreService.fetchSavedPosts(uid),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final posts = snapshot.data!;
        if (posts.isEmpty) return const Center(child: Text('No saved posts'));
        return ListView.builder(
          itemCount: posts.length,
          itemBuilder: (context, index) => PostCard(
            post: posts[index],
            currentUid: uid,
            isSaved: true,
            onLike: () {},
            onReport: () {},
            onSave: () => firestoreService.toggleSavePost(uid, posts[index].id, true),
          ),
        );
      },
    );
  }
}
