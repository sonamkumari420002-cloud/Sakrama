import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/post_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/post_provider.dart';
import '../../services/firestore_service.dart';
import '../../widgets/post_card.dart';
import '../../widgets/loading_shimmer.dart';
import '../post/create_post_screen.dart';

/// Community acts as a discussion-focused view of the same posts collection,
/// framed around village issues and opinions rather than a general feed.
class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  final FirestoreService _firestoreService = FirestoreService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.read<PostProvider>().posts.isEmpty) {
        context.read<PostProvider>().loadInitial();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final postProvider = context.watch<PostProvider>();
    final uid = context.watch<AuthProvider>().currentUser?.uid ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Community')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const CreatePostScreen())),
        child: const Icon(Icons.add_comment_outlined),
      ),
      body: RefreshIndicator(
        onRefresh: () => postProvider.refresh(),
        child: postProvider.posts.isEmpty && postProvider.isLoading
            ? const ListShimmer()
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 80),
                itemCount: postProvider.posts.length,
                itemBuilder: (context, index) {
                  final post = postProvider.posts[index];
                  return PostCard(
                    post: post,
                    currentUid: uid,
                    onLike: () => postProvider.toggleLike(post.id, uid),
                    onReport: () async {
                      await _firestoreService.reportPost(post.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Post reported to admins')),
                        );
                      }
                    },
                    onSave: () async {
                      await _firestoreService.toggleSavePost(uid, post.id, false);
                    },
                  );
                },
              ),
      ),
    );
  }
}
