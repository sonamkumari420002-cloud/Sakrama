import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../models/post_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import 'media_viewer_screen.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> with SingleTickerProviderStateMixin {
  final FirestoreService _firestoreService = FirestoreService();
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Village Gallery'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: 'Photos', icon: Icon(Icons.photo_outlined)),
            Tab(text: 'Videos', icon: Icon(Icons.videocam_outlined)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _PhotoGrid(firestoreService: _firestoreService),
          _VideoGrid(firestoreService: _firestoreService),
        ],
      ),
    );
  }
}

class _PhotoGrid extends StatelessWidget {
  final FirestoreService firestoreService;
  const _PhotoGrid({required this.firestoreService});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<PostModel>>(
      future: firestoreService.fetchGalleryMedia(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final allImages = <String>[];
        for (final post in snapshot.data!) {
          allImages.addAll(post.imageUrls);
        }
        if (allImages.isEmpty) {
          return const Center(child: Text('No photos shared yet'));
        }
        return GridView.builder(
          padding: const EdgeInsets.all(4),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
          ),
          itemCount: allImages.length,
          itemBuilder: (context, index) => GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MediaViewerScreen(mediaUrls: allImages, initialIndex: index),
              ),
            ),
            child: CachedNetworkImage(
              imageUrl: allImages[index],
              fit: BoxFit.cover,
              placeholder: (context, url) => Container(color: AppColors.paleGreen),
              errorWidget: (context, url, error) => const Icon(Icons.broken_image),
            ),
          ),
        );
      },
    );
  }
}

class _VideoGrid extends StatelessWidget {
  final FirestoreService firestoreService;
  const _VideoGrid({required this.firestoreService});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<PostModel>>(
      future: firestoreService.fetchGalleryMedia(videosOnly: true),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final videos = snapshot.data!;
        if (videos.isEmpty) {
          return const Center(child: Text('No videos shared yet'));
        }
        return GridView.builder(
          padding: const EdgeInsets.all(4),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
            childAspectRatio: 1.4,
          ),
          itemCount: videos.length,
          itemBuilder: (context, index) => GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MediaViewerScreen(
                  mediaUrls: [videos[index].videoUrl!],
                  initialIndex: 0,
                  isVideo: true,
                ),
              ),
            ),
            child: Container(
              color: Colors.black87,
              child: const Center(
                child: Icon(Icons.play_circle_fill, color: Colors.white, size: 40),
              ),
            ),
          ),
        );
      },
    );
  }
}
