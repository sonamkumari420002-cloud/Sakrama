import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/post_provider.dart';
import '../../services/firestore_service.dart';
import '../../widgets/post_card.dart';
import '../../widgets/loading_shimmer.dart';
import '../search/search_screen.dart';
import '../notifications/notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  final FirestoreService _firestoreService = FirestoreService();
  final Set<String> _savedIds = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PostProvider>().loadInitial();
      _loadSavedIds();
    });
    _scrollController.addListener(_onScroll);
  }

  Future<void> _loadSavedIds() async {
    final uid = context.read<AuthProvider>().currentUser?.uid;
    if (uid == null) return;
    final saved = await _firestoreService.fetchSavedPosts(uid);
    if (mounted) {
      setState(() {
        _savedIds.addAll(saved.map((p) => p.id));
      });
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 300) {
      context.read<PostProvider>().loadMore();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final postProvider = context.watch<PostProvider>();
    final uid = context.watch<AuthProvider>().currentUser?.uid ?? '';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sakrama Gaon'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NotificationsScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => postProvider.refresh(),
        child: postProvider.posts.isEmpty && postProvider.isLoading
            ? const ListShimmer()
            : postProvider.posts.isEmpty
                ? ListView(
                    children: const [
                      SizedBox(height: 120),
                      Center(child: Icon(Icons.eco_outlined, size: 56, color: Colors.grey)),
                      SizedBox(height: 12),
                      Center(child: Text('No posts yet. Be the first to share!')),
                    ],
                  )
                : ListView.builder(
                    controller: _scrollController,
                    itemCount: postProvider.posts.length + 1,
                    itemBuilder: (context, index) {
                      if (index == postProvider.posts.length) {
                        return postProvider.hasMore
                            ? const Padding(
                                padding: EdgeInsets.all(16),
                                child: Center(child: CircularProgressIndicator()),
                              )
                            : const Padding(
                                padding: EdgeInsets.all(16),
                                child: Center(
                                  child: Text("You're all caught up 🌾",
                                      style: TextStyle(color: Colors.grey)),
                                ),
                              );
                      }
                      final post = postProvider.posts[index];
                      return PostCard(
                        post: post,
                        currentUid: uid,
                        isSaved: _savedIds.contains(post.id),
                        onLike: () => postProvider.toggleLike(post.id, uid),
                        onReport: () async {
                          await _firestoreService.reportPost(post.id);
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Post reported to admins')),
                            );
                          }
                        },
                        onSave: () async {
                          final isSaved = _savedIds.contains(post.id);
                          await _firestoreService.toggleSavePost(uid, post.id, isSaved);
                          setState(() {
                            if (isSaved) {
                              _savedIds.remove(post.id);
                            } else {
                              _savedIds.add(post.id);
                            }
                          });
                        },
                      );
                    },
                  ),
      ),
    );
  }
}
