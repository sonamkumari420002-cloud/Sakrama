import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../models/event_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';
import 'create_event_screen.dart';
import 'event_detail_screen.dart';

class EventsScreen extends StatefulWidget {
  const EventsScreen({super.key});

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Village Events')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const CreateEventScreen())),
        icon: const Icon(Icons.add),
        label: const Text('Add Event'),
      ),
      body: StreamBuilder<List<EventModel>>(
        stream: _firestoreService.streamEvents(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final events = snapshot.data!;
          final eventsByDay = <DateTime, List<EventModel>>{};
          for (final e in events) {
            final day = DateTime(e.startTime.year, e.startTime.month, e.startTime.day);
            eventsByDay.putIfAbsent(day, () => []).add(e);
          }

          final selected = _selectedDay ?? _focusedDay;
          final selectedKey = DateTime(selected.year, selected.month, selected.day);
          final dayEvents = eventsByDay[selectedKey] ?? [];

          return Column(
            children: [
              TableCalendar(
                firstDay: DateTime.now().subtract(const Duration(days: 365)),
                lastDay: DateTime.now().add(const Duration(days: 365)),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                eventLoader: (day) {
                  final key = DateTime(day.year, day.month, day.day);
                  return eventsByDay[key] ?? [];
                },
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDay = selectedDay;
                    _focusedDay = focusedDay;
                  });
                },
                calendarStyle: const CalendarStyle(
                  todayDecoration: BoxDecoration(color: AppColors.lightGreen, shape: BoxShape.circle),
                  selectedDecoration: BoxDecoration(color: AppColors.primaryGreen, shape: BoxShape.circle),
                  markerDecoration: BoxDecoration(color: AppColors.accentGold, shape: BoxShape.circle),
                ),
                headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
              ),
              const Divider(),
              Expanded(
                child: dayEvents.isEmpty
                    ? const Center(child: Text('No events on this day'))
                    : ListView.builder(
                        itemCount: dayEvents.length,
                        itemBuilder: (context, index) {
                          final event = dayEvents[index];
                          final interested = user != null && event.interested.contains(user.uid);
                          return Card(
                            child: ListTile(
                              leading: const CircleAvatar(
                                backgroundColor: AppColors.paleGreen,
                                child: Icon(Icons.event, color: AppColors.primaryGreen),
                              ),
                              title: Text(event.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Text(
                                  '${event.location}\n${TimeOfDay.fromDateTime(event.startTime).format(context)}'),
                              isThreeLine: true,
                              trailing: IconButton(
                                icon: Icon(interested ? Icons.notifications_active : Icons.notifications_outlined,
                                    color: interested ? AppColors.accentGold : null),
                                onPressed: () {
                                  if (user != null) {
                                    _firestoreService.toggleInterested(event.id, user.uid, interested);
                                  }
                                },
                              ),
                              onTap: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) => EventDetailScreen(event: event))),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
