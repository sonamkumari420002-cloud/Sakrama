import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../models/event_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_theme.dart';

class EventDetailScreen extends StatelessWidget {
  final EventModel event;
  const EventDetailScreen({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;
    final dateFormat = DateFormat('EEEE, d MMMM yyyy');
    final timeFormat = DateFormat('h:mm a');
    final interested = user != null && event.interested.contains(user.uid);

    return Scaffold(
      appBar: AppBar(title: const Text('Event Details')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(event.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _infoRow(Icons.calendar_today, dateFormat.format(event.startTime)),
            const SizedBox(height: 8),
            _infoRow(Icons.access_time,
                '${timeFormat.format(event.startTime)} - ${timeFormat.format(event.endTime)}'),
            const SizedBox(height: 8),
            _infoRow(Icons.location_on_outlined, event.location.isEmpty ? 'Village center' : event.location),
            const SizedBox(height: 20),
            const Text('About this event', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            const SizedBox(height: 8),
            Text(event.description),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: user == null
                    ? null
                    : () => FirestoreService().toggleInterested(event.id, user.uid, interested),
                icon: Icon(interested ? Icons.notifications_active : Icons.notifications_outlined),
                label: Text(interested ? "You'll be reminded" : 'Remind me'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: interested ? AppColors.accentGold : AppColors.primaryGreen,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppColors.primaryGreen),
        const SizedBox(width: 10),
        Expanded(child: Text(text)),
      ],
    );
  }
}
