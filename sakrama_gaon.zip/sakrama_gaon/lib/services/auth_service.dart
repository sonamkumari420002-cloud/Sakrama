import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email', 'profile']);

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Sign in with Google and create/update the Firestore user document.
  Future<UserModel?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential = await _auth.signInWithCredential(credential);
    final firebaseUser = userCredential.user;
    if (firebaseUser == null) return null;

    return _upsertUserDoc(
      uid: firebaseUser.uid,
      name: firebaseUser.displayName ?? 'Villager',
      email: firebaseUser.email,
      photoUrl: firebaseUser.photoURL ?? '',
    );
  }

  /// Step 1 of phone auth: send OTP. [codeSent] receives the verificationId.
  Future<void> sendOtp({
    required String phoneNumber,
    required void Function(String verificationId) codeSent,
    required void Function(String error) onError,
    required void Function(UserModel user) onAutoVerified,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        final result = await _auth.signInWithCredential(credential);
        final u = result.user;
        if (u != null) {
          final userModel = await _upsertUserDoc(
            uid: u.uid,
            name: u.displayName ?? 'Villager',
            phone: u.phoneNumber,
            photoUrl: '',
          );
          onAutoVerified(userModel);
        }
      },
      verificationFailed: (FirebaseAuthException e) {
        onError(e.message ?? 'Verification failed');
      },
      codeSent: (String verificationId, int? resendToken) {
        codeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  /// Step 2 of phone auth: verify the OTP code entered by the user.
  Future<UserModel?> verifyOtp({
    required String verificationId,
    required String smsCode,
    required String displayName,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final result = await _auth.signInWithCredential(credential);
    final u = result.user;
    if (u == null) return null;
    return _upsertUserDoc(
      uid: u.uid,
      name: displayName.isNotEmpty ? displayName : 'Villager',
      phone: u.phoneNumber,
      photoUrl: '',
    );
  }

  Future<UserModel> _upsertUserDoc({
    required String uid,
    required String name,
    String? email,
    String? phone,
    String photoUrl = '',
  }) async {
    final docRef = _db.collection('users').doc(uid);
    final snap = await docRef.get();

    if (!snap.exists) {
      final newUser = UserModel(
        uid: uid,
        name: name,
        email: email,
        phone: phone,
        photoUrl: photoUrl,
        createdAt: DateTime.now(),
      );
      await docRef.set(newUser.toMap());
      return newUser;
    } else {
      return UserModel.fromMap(snap.data()!, uid);
    }
  }

  Future<UserModel?> fetchUserProfile(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    if (!snap.exists) return null;
    return UserModel.fromMap(snap.data()!, uid);
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
