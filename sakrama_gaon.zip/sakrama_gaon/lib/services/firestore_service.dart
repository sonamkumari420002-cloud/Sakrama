import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/post_model.dart';
import '../models/notice_model.dart';
import '../models/event_model.dart';
import '../models/user_model.dart';
import '../models/notification_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference get _posts => _db.collection('posts');
  CollectionReference get _notices => _db.collection('notices');
  CollectionReference get _events => _db.collection('events');
  CollectionReference get _users => _db.collection('users');
  CollectionReference get _notifications => _db.collection('notifications');

  // ---------------- POSTS ----------------

  Future<void> createPost(PostModel post) async {
    await _posts.add(post.toMap());
  }

  /// Paginated feed query, newest first, approved posts only.
  Future<List<PostModel>> fetchFeed({
    DocumentSnapshot? lastDoc,
    int limit = 10,
  }) async {
    Query query = _posts
        .where('isApproved', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .limit(limit);
    if (lastDoc != null) {
      query = query.startAfterDocument(lastDoc);
    }
    final snap = await query.get();
    return snap.docs
        .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
  }

  Future<QuerySnapshot> fetchFeedRaw({DocumentSnapshot? lastDoc, int limit = 10}) async {
    Query query = _posts
        .where('isApproved', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .limit(limit);
    if (lastDoc != null) query = query.startAfterDocument(lastDoc);
    return query.get();
  }

  Future<void> toggleLike(String postId, String uid, bool isLiked) async {
    await _posts.doc(postId).update({
      'likes': isLiked
          ? FieldValue.arrayRemove([uid])
          : FieldValue.arrayUnion([uid]),
    });
  }

  Future<void> addComment(String postId, CommentModel comment) async {
    await _posts.doc(postId).collection('comments').add(comment.toMap());
    await _posts.doc(postId).update({'commentCount': FieldValue.increment(1)});
  }

  Stream<List<CommentModel>> streamComments(String postId) {
    return _posts
        .doc(postId)
        .collection('comments')
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => CommentModel.fromMap(d.data(), d.id))
            .toList());
  }

  Future<void> reportPost(String postId) async {
    await _posts.doc(postId).update({'isReported': true});
  }

  Future<List<PostModel>> fetchUserPosts(String uid) async {
    final snap = await _posts
        .where('authorId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs
        .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
  }

  // ---------------- SAVED POSTS ----------------

  Future<void> toggleSavePost(String uid, String postId, bool isSaved) async {
    final ref = _users.doc(uid).collection('saved').doc(postId);
    if (isSaved) {
      await ref.delete();
    } else {
      await ref.set({'savedAt': Timestamp.now()});
    }
  }

  Future<List<PostModel>> fetchSavedPosts(String uid) async {
    final savedSnap = await _users.doc(uid).collection('saved').get();
    final ids = savedSnap.docs.map((d) => d.id).toList();
    if (ids.isEmpty) return [];
    final posts = <PostModel>[];
    for (final id in ids) {
      final doc = await _posts.doc(id).get();
      if (doc.exists) {
        posts.add(PostModel.fromMap(doc.data() as Map<String, dynamic>, doc.id));
      }
    }
    return posts;
  }

  // ---------------- NOTICES ----------------

  Future<void> createNotice(NoticeModel notice) async {
    await _notices.add(notice.toMap());
  }

  Stream<List<NoticeModel>> streamNotices({NoticeCategory? category}) {
    Query query = _notices.orderBy('createdAt', descending: true);
    if (category != null) {
      query = query.where('category', isEqualTo: category.name);
    }
    return query.snapshots().map((snap) => snap.docs
        .map((d) => NoticeModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList());
  }

  Future<void> deleteNotice(String id) async {
    await _notices.doc(id).delete();
  }

  // ---------------- EVENTS ----------------

  Future<void> createEvent(EventModel event) async {
    await _events.add(event.toMap());
  }

  Stream<List<EventModel>> streamEvents() {
    return _events.orderBy('startTime', descending: false).snapshots().map(
        (snap) => snap.docs
            .map((d) => EventModel.fromMap(d.data() as Map<String, dynamic>, d.id))
            .toList());
  }

  Future<void> toggleInterested(String eventId, String uid, bool isInterested) async {
    await _events.doc(eventId).update({
      'interested': isInterested
          ? FieldValue.arrayRemove([uid])
          : FieldValue.arrayUnion([uid]),
    });
  }

  // ---------------- GALLERY ----------------

  Future<List<PostModel>> fetchGalleryMedia({bool videosOnly = false}) async {
    Query query = _posts.where('isApproved', isEqualTo: true);
    final snap = await query.orderBy('createdAt', descending: true).get();
    final all = snap.docs
        .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
    if (videosOnly) {
      return all.where((p) => p.videoUrl != null && p.videoUrl!.isNotEmpty).toList();
    }
    return all.where((p) => p.imageUrls.isNotEmpty).toList();
  }

  // ---------------- SEARCH ----------------

  Future<List<UserModel>> searchUsers(String query) async {
    if (query.trim().isEmpty) return [];
    final lower = query.toLowerCase();
    final snap = await _users
        .orderBy('name')
        .startAt([lower])
        .endAt(['$lower\uf8ff'])
        .limit(20)
        .get();
    return snap.docs
        .map((d) => UserModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
  }

  Future<List<PostModel>> searchPosts(String query) async {
    if (query.trim().isEmpty) return [];
    final snap = await _posts
        .where('isApproved', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .get();
    final all = snap.docs
        .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
    return all
        .where((p) => p.text.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  Future<List<EventModel>> searchEvents(String query) async {
    if (query.trim().isEmpty) return [];
    final snap = await _events.orderBy('startTime').get();
    final all = snap.docs
        .map((d) => EventModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
    return all
        .where((e) => e.title.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  // ---------------- NOTIFICATIONS ----------------

  Future<void> pushNotification(NotificationModel n) async {
    await _notifications.add(n.toMap());
  }

  Stream<List<NotificationModel>> streamNotifications(String uid) {
    return _notifications
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => NotificationModel.fromMap(d.data() as Map<String, dynamic>, d.id))
            .toList());
  }

  Future<void> markNotificationRead(String id) async {
    await _notifications.doc(id).update({'isRead': true});
  }

  // ---------------- ADMIN ----------------

  Future<List<PostModel>> fetchReportedPosts() async {
    final snap = await _posts.where('isReported', isEqualTo: true).get();
    return snap.docs
        .map((d) => PostModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
  }

  Future<void> approvePost(String id) async {
    await _posts.doc(id).update({'isApproved': true, 'isReported': false});
  }

  Future<void> deletePost(String id) async {
    await _posts.doc(id).delete();
  }

  Future<void> banUser(String uid, bool banned) async {
    await _users.doc(uid).update({'isBanned': banned});
  }

  Future<List<UserModel>> fetchAllUsers() async {
    final snap = await _users.orderBy('createdAt', descending: true).get();
    return snap.docs
        .map((d) => UserModel.fromMap(d.data() as Map<String, dynamic>, d.id))
        .toList();
  }

  // ---------------- PROFILE ----------------

  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    await _users.doc(uid).update(data);
  }

  Future<void> toggleFollow(String currentUid, String targetUid, bool isFollowing) async {
    final batch = _db.batch();
    final currentRef = _users.doc(currentUid);
    final targetRef = _users.doc(targetUid);
    if (isFollowing) {
      batch.update(currentRef, {'following': FieldValue.arrayRemove([targetUid])});
      batch.update(targetRef, {'followers': FieldValue.arrayRemove([currentUid])});
    } else {
      batch.update(currentRef, {'following': FieldValue.arrayUnion([targetUid])});
      batch.update(targetRef, {'followers': FieldValue.arrayUnion([currentUid])});
    }
    await batch.commit();
  }
}
