import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final Uuid _uuid = const Uuid();

  /// Uploads a single file and reports progress via [onProgress] (0.0-1.0).
  Future<String> uploadFile({
    required File file,
    required String folder,
    void Function(double progress)? onProgress,
  }) async {
    final ext = file.path.split('.').last;
    final fileName = '${_uuid.v4()}.$ext';
    final ref = _storage.ref().child('$folder/$fileName');

    final uploadTask = ref.putFile(file);
    uploadTask.snapshotEvents.listen((snapshot) {
      if (snapshot.totalBytes > 0) {
        onProgress?.call(snapshot.bytesTransferred / snapshot.totalBytes);
      }
    });

    final snapshot = await uploadTask;
    return snapshot.ref.getDownloadURL();
  }

  /// Uploads multiple images sequentially, reporting overall progress.
  Future<List<String>> uploadMultipleImages({
    required List<File> files,
    required String folder,
    void Function(double overallProgress)? onProgress,
  }) async {
    final urls = <String>[];
    for (var i = 0; i < files.length; i++) {
      final url = await uploadFile(
        file: files[i],
        folder: folder,
        onProgress: (p) {
          final overall = (i + p) / files.length;
          onProgress?.call(overall);
        },
      );
      urls.add(url);
    }
    return urls;
  }

  Future<void> deleteFile(String downloadUrl) async {
    try {
      final ref = _storage.refFromURL(downloadUrl);
      await ref.delete();
    } catch (_) {
      // File may already be deleted; ignore.
    }
  }
}
