import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:share_plus/share_plus.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/post_model.dart';
import '../utils/app_theme.dart';
import '../screens/post/comments_screen.dart';
import '../screens/gallery/media_viewer_screen.dart';

class PostCard extends StatelessWidget {
  final PostModel post;
  final String currentUid;
  final VoidCallback onLike;
  final VoidCallback onReport;
  final VoidCallback onSave;
  final bool isSaved;

  const PostCard({
    super.key,
    required this.post,
    required this.currentUid,
    required this.onLike,
    required this.onReport,
    required this.onSave,
    this.isSaved = false,
  });

  @override
  Widget build(BuildContext context) {
    final isLiked = post.likes.contains(currentUid);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: AppColors.paleGreen,
                  backgroundImage: post.authorPhoto.isNotEmpty
                      ? CachedNetworkImageProvider(post.authorPhoto)
                      : null,
                  child: post.authorPhoto.isEmpty
                      ? Text(post.authorName.isNotEmpty
                          ? post.authorName[0].toUpperCase()
                          : 'V')
                      : null,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(post.authorName,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text(
                        '${post.village.isNotEmpty ? '${post.village} • ' : ''}${timeago.format(post.createdAt)}',
                        style: TextStyle(fontSize: 12, color: AppColors.textGrey),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'report') onReport();
                    if (value == 'save') onSave();
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'save',
                      child: Text(isSaved ? 'Unsave' : 'Save post'),
                    ),
                    const PopupMenuItem(value: 'report', child: Text('Report')),
                  ],
                ),
              ],
            ),
            if (post.text.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(post.text),
            ],
            if (post.imageUrls.isNotEmpty) ...[
              const SizedBox(height: 10),
              _buildImageGrid(context),
            ],
            if (post.videoUrl != null) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => MediaViewerScreen(
                      mediaUrls: [post.videoUrl!],
                      initialIndex: 0,
                      isVideo: true,
                    ),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    height: 200,
                    color: Colors.black87,
                    child: const Center(
                      child: Icon(Icons.play_circle_fill,
                          color: Colors.white, size: 56),
                    ),
                  ),
                ),
              ),
            ],
            const Divider(height: 20),
            Row(
              children: [
                _actionButton(
                  icon: isLiked ? Icons.favorite : Icons.favorite_border,
                  label: '${post.likes.length}',
                  color: isLiked ? Colors.red : AppColors.textGrey,
                  onTap: onLike,
                ),
                const SizedBox(width: 20),
                _actionButton(
                  icon: Icons.mode_comment_outlined,
                  label: '${post.commentCount}',
                  color: AppColors.textGrey,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => CommentsScreen(postId: post.id)),
                  ),
                ),
                const SizedBox(width: 20),
                _actionButton(
                  icon: Icons.share_outlined,
                  label: 'Share',
                  color: AppColors.textGrey,
                  onTap: () => Share.share(
                    '${post.authorName} shared on Sakrama Gaon: ${post.text}',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageGrid(BuildContext context) {
    final urls = post.imageUrls;
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: urls.length > 4 ? 4 : urls.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: urls.length == 1 ? 1 : 2,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
          childAspectRatio: urls.length == 1 ? 16 / 10 : 1,
        ),
        itemBuilder: (context, index) {
          final isLastVisible = index == 3 && urls.length > 4;
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MediaViewerScreen(
                  mediaUrls: urls,
                  initialIndex: index,
                ),
              ),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                CachedNetworkImage(
                  imageUrl: urls[index],
                  fit: BoxFit.cover,
                  placeholder: (context, url) =>
                      Container(color: AppColors.paleGreen),
                  errorWidget: (context, url, error) =>
                      const Icon(Icons.broken_image),
                ),
                if (isLastVisible)
                  Container(
                    color: Colors.black54,
                    child: Center(
                      child: Text(
                        '+${urls.length - 4}',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _actionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: color, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
