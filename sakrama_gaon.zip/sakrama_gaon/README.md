# Sakrama Gaon — Village Community App

A Flutter + Firebase community app for Indian villages: feed, community
discussions, notice board, events calendar, gallery, profiles, search,
notifications, and an admin panel.

## What's included

- Full `lib/` source: models, services, providers, screens, widgets — all
  real implementations wired to Firebase (no TODOs in the Dart code).
- Material 3 UI, green/white village theme, dark mode, splash screen,
  5-tab bottom navigation.
- Android project (`android/`) with manifest permissions, Gradle files,
  ProGuard rules.
- Firestore & Storage security rules (`firestore.rules`, `storage.rules`).

## What you must do before it will run

This app talks to **your own Firebase project** — I can't generate real
API keys on your behalf. Two files are placeholders and must be replaced:

- `lib/firebase_options.dart`
- `android/app/google-services.json` (see `.example` file provided)

### Step-by-step setup

1. **Install tooling**
   ```bash
   flutter --version   # needs Flutter 3.19+ (Dart 3.3+)
   dart pub global activate flutterfire_cli
   npm install -g firebase-tools   # if you don't have the Firebase CLI
   firebase login
   ```

2. **Create the Firebase project**
   - Go to https://console.firebase.google.com → Add project.
   - In the project, enable:
     - **Authentication** → Sign-in method → enable **Google** and **Phone**.
     - **Firestore Database** → Create database (start in production mode).
     - **Storage** → Get started.
     - **Cloud Messaging** → already on by default.

3. **Connect the Flutter app to Firebase**
   From the project root:
   ```bash
   flutterfire configure
   ```
   Select your Firebase project and the `android` platform. This
   overwrites `lib/firebase_options.dart` with real values and drops a
   real `android/app/google-services.json` in place automatically.

4. **Add your SHA-1/SHA-256 fingerprints** (required for Google Sign-In)
   ```bash
   cd android && ./gradlew signingReport
   ```
   Copy the SHA-1 and SHA-256 into Firebase Console → Project Settings →
   Your Android app.

5. **Deploy security rules**
   ```bash
   firebase deploy --only firestore:rules,storage:rules
   ```

6. **Create `android/local.properties`**
   Copy `android/local.properties.example` → `android/local.properties`
   and set `sdk.dir` / `flutter.sdk` to your local paths.

7. **Get packages**
   ```bash
   flutter pub get
   ```

8. **Make the first user an admin**
   Sign in once from the app, then in the Firestore console open
   `users/{your-uid}` and set `isAdmin: true`. This unlocks the Admin
   Panel (approve/delete posts, ban users, post notices) from the
   Profile screen's overflow menu.

## Running the app

```bash
flutter run                       # debug, on a connected device/emulator
```

## Building the APK

```bash
flutter build apk --release       # unsigned-by-debug-key release APK
```
The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

Before publishing to the Play Store, replace the debug signing config in
`android/app/build.gradle` (`signingConfig signingConfigs.debug`) with
your own release keystore — generate one with:
```bash
keytool -genkey -v -keystore ~/sakrama-gaon-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias sakrama
```
then add a `signingConfigs.release` block referencing it and point
`buildTypes.release.signingConfig` at it.

## Project structure

```
lib/
  main.dart
  firebase_options.dart      # regenerate via flutterfire configure
  models/                    # UserModel, PostModel, NoticeModel, EventModel, NotificationModel
  services/                  # AuthService, FirestoreService, StorageService, FcmService
  providers/                 # AuthProvider, PostProvider, ThemeProvider
  screens/
    splash/, auth/, home/, post/, community/, notice/,
    events/, gallery/, profile/, search/, notifications/, admin/
  widgets/                   # PostCard, shimmer loaders, bottom nav
  utils/                     # AppTheme (green/white Material 3, dark mode)
```

## Known limitations / next steps

- **Offline cache**: Firestore's built-in disk persistence is enabled by
  default on Android, so reads work offline once cached; there's no
  custom Hive-based cache layer wired in yet, though the `hive` package
  is included in `pubspec.yaml` if you want to add one.
- **Followers/Following** are tracked in Firestore but there's no
  dedicated followers-list screen yet — only counts on the profile.
- **Push notifications**: `FcmService` requests permission, stores the
  device token, and displays foreground notifications. Sending
  notifications when someone likes/comments/posts a notice requires a
  small **Cloud Function** (not included) that listens for new
  `notifications` documents / Firestore writes and calls the FCM Admin
  SDK — this is standard Firebase practice and needs to run server-side,
  not from the Flutter app.
- **iOS**: this deliverable targets Android only, per the request. Adding
  iOS is mostly `flutterfire configure` + an `ios/` folder + Xcode signing.

## Troubleshooting

- **Google Sign-In fails silently**: almost always a missing/incorrect
  SHA-1 fingerprint in Firebase Console (see step 4).
- **Phone OTP not arriving on a real device**: check that Play Integrity
  / SafetyNet is set up (Firebase handles this automatically once the
  SHA fingerprints are registered) and that billing is enabled if you
  exceed the free OTP quota.
- **Build fails on `google-services.json` missing**: you skipped step 3;
  run `flutterfire configure`.
